import { Request, Response } from "express";
import { ProviderService } from "../services/providerService";

const providerService = new ProviderService();

export class ProviderController {
  async list(req: Request, res: Response) {
    const providers = await providerService.getAllProviders();
    return res.json(providers);
  }

  async get(req: Request, res: Response) {
    const { id } = req.params;
    const provider = await providerService.getProviderById(id);
    return res.json(provider);
  }

  async create(req: Request, res: Response) {
    const created = await providerService.createProvider(req.body);
    return res.status(201).json(created);
  }

  async update(req: Request, res: Response) {
    const { id } = req.params;
    const updated = await providerService.updateProvider(id, req.body);
    return res.json(updated);
  }

  async remove(req: Request, res: Response) {
    const { id } = req.params;
    await providerService.deleteProvider(id);
    return res.status(204).send();
  }
}
